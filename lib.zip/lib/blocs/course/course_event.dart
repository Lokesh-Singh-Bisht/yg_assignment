abstract class CourseEvent {}

class FetchCourses extends CourseEvent {}
