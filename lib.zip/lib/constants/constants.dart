class AppConstants {
  static String dummyUserId = 'userId1';
  static int zegoAppId = 393337636;
  static String zegoAppSign =
      'f5db516a10ea14eed0cce38fd3ddb22142d0ad5bd45b62a98a8e19def8029a54';
}
